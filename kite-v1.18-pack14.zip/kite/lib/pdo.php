<?php
/*
** KITE - A NANO PHP MVC FRAMEWORK
** Author - Krishna Teja G S
** website - packetcode.com
*/

//package - lib/pdo.php

// A class to do database operations using phpdataobject

class pdo{

	

}
?>