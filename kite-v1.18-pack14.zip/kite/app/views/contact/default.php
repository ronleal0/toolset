<h1>This is contact page</h1>

<form role="form">
  <div class="form-group">
    <label for="exampleInputEmail1">Email address</label>
    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
  </div>
  <textarea class="form-control" rows="5"></textarea>

  <button type="submit" class="btn btn-default">Submit</button>
  <br><Br>
</form>